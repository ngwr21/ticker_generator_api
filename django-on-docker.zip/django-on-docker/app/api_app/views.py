import os
import json
import subprocess
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from .models import Printer, Check
from django.http import HttpResponse
from django.conf import settings
import mimetypes
import os
# from .task import generate_pdf_task


# @csrf_exempt
# def create_check(request, api_key):
#     if request.method == 'POST':
#         try:
#             printer = Printer.objects.get(api_key=api_key)
#         except Printer.DoesNotExist:
#             return JsonResponse({'error': 'Invalid API key'})
#
#         data = json.loads(request.body)
#         check_type = data['check_type']
#
#         created_checks = []
#
#
#         check1 = Check(printer=printer, check_type=check_type, order=data)
#         check1.save()
#         created_checks.append(check1.id)
#
#
#         if check_type == Printer.CLIENT:
#             check2_type = Printer.KITCHEN
#         else:
#             check2_type = Printer.CLIENT
#
#         check2 = Check(printer=printer, check_type=check2_type, order=data)
#         check2.save()
#         created_checks.append(check2.id)
#
#         return JsonResponse({'success': created_checks})
#
#     else:
#         return JsonResponse({'error': 'Invalid request method'})
#
#
@csrf_exempt
def create_check(request, api_key):
    if request.method == 'POST':
        try:
            printer = Printer.objects.get(api_key=api_key)
        except Printer.DoesNotExist:
            return JsonResponse({'error': 'Invalid API key'})

        data = json.loads(request.body)
        check_type = data['fields']['check_type']
        created_checks = []

        # Створити перший чек
        check1 = Check(printer=printer, check_type=check_type, order=data)
        check1.save()
        created_checks.append(check1.id)

        # Створити другий чек з іншим check_type
        if check_type == Printer.CLIENT:
            check2_type = Printer.KITCHEN
        else:
            check2_type = Printer.CLIENT

        check2 = Check(printer=printer, check_type=check2_type, order=data)
        check2.save()
        created_checks.append(check2.id)

        return JsonResponse({'success': created_checks})

    else:
        return JsonResponse({'error': 'Invalid request method'})

# @csrf_exempt
# def create_check(request, api_key):
#     if request.method == 'POST':
#         try:
#             printer = Printer.objects.get(api_key=api_key)
#         except Printer.DoesNotExist:
#             return JsonResponse({'error': 'Invalid API key'})
#         data = json.loads(request.body)
#         test = Check.objects.filter(order__fields__order__id=data['fields']['order']['id'])
#         print(test)
#         if test.exists():
#           return JsonResponse({'error': 'Check already exists', 'id': test.first().order['fields']['order']['id']})
#         check = Check(printer=printer, check_type=printer.check_type, order=data)
#         check.save()
#         # generate_pdf_task(check.id, printer.check_type)
#
#         return JsonResponse({'success': check.id})
#
#     else:
#         return JsonResponse({'error': 'Invalid request method'})

@csrf_exempt
def generate_pdf(request, api_key, check_id):
    try:
        printer = Printer.objects.get(api_key=api_key)
    except Printer.DoesNotExist:
        return JsonResponse({'error': 'Invalid API key'})
    check = get_object_or_404(Check, pk=check_id, printer=printer)
    if check.status == Check.PRINTED:
        return JsonResponse({'error': 'PDF already generated'})
    html = '<html><head><title>Check</title></head><body>'
    for item in check.order['items']:
        html += f'<p>{item["name"]}: {item["price"]}</p>'
    html += f'<p>Total: {check.order["total"]}</p>'
    html += '</body></html>'
    filename = f'{check.id}.pdf'
    filepath = os.path.join('pdfs', filename)
    try:
        subprocess.run(['wkhtmltopdf', '-', filepath], input=html.encode(), check=True)
        check.status = Check.PRINTED
        check.pdf_file.name = filename
        check.save()
        return JsonResponse({'success': True})
    except subprocess.CalledProcessError as e:
        return JsonResponse({'error': 'Failed to generate PDF'})

def list_checks(request, api_key):
    try:
        printer = Printer.objects.get(api_key=api_key)
    except Printer.DoesNotExist:
        return JsonResponse({'error': 'Invalid API key'})
    checks = Check.objects.filter(printer=printer)
    check_list = [{'id': c.id, 'order': c.order} for c in checks]
    return JsonResponse({'checks': check_list})


def download_pdf(request, api_key, check_id):
    try:
        printer = Printer.objects.get(api_key=api_key)
    except Printer.DoesNotExist:
        return JsonResponse({'error': 'Invalid API key'})
    check = get_object_or_404(Check, pk=check_id, printer=printer)
    if check.status != Check.PRINTED:
        return JsonResponse({'error': 'PDF not generated yet'})
    pdf_path = check.pdf_file.path
    if not os.path.exists(pdf_path):
        return JsonResponse({'error': 'PDF file not found'})
    with open(pdf_path, 'rb') as f:
        pdf_data = f.read()
    response = HttpResponse(pdf_data, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{check_id}.pdf"'
    return response