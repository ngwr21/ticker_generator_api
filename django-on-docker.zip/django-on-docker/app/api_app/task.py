# from __future__ import absolute_import, unicode_literals
# from celery import shared_task
# from .models import Check
# import subprocess
# import os
#
#
# @shared_task
# def generate_pdf_task(check_id, check_type):
#     check = Check.objects.get(id=check_id)
#     if check.status == Check.PRINTED:
#         return
#     html = '<html><head><title>Check</title></head><body>'
#
#     for item in check.order.items:
#         html += f'<p>{item["name"]}: {item["price"]}</p>'
#     html += f'<p>Total: {check.order["total"]}</p>'
#     html += '</body></html>'
#     filename = f'{check_id}_{check_type}.pdf'
#     filepath = os.path.join(settings.MEDIA_ROOT, 'pdf', filename)
#     try:
#         subprocess.run(['wkhtmltopdf', '-', filepath], input=html.encode(), check=True)
#         check.status = Check.PRINTED
#         with open(filepath, 'rb') as f:
#             check.pdf_file.save(filename, File(f))
#         check.save()
#     except subprocess.CalledProcessError as e:
#         pass
